(function () {
  if (!location.hostname.includes("zillow.com")) return;
  if (document.getElementById("tzvl-root")) return;
  let lang = navigator.language && navigator.language.toLowerCase().startsWith("zh") ? "zh" : "en";

  const I18N = {
    zh: {
      eyebrow: "Tucson Zillow Value Lens",
      title: "未來房價試算",
      currentPrice: "目前價格",
      foreign: "外國人出售 FIRPTA",
      years: "年",
      advanced: "房貸與成長設定",
      down: "頭期款 %",
      rate: "房貸利率 %",
      app: "潛力年增率調整 %",
      range: "區間",
      annualGrowth: "年增率",
      remain: "剩餘房貸",
      netProceeds: "賣房淨回收",
      buyClosing: "買入 closing",
      annualCarry: "年持有成本",
      saleCosts: "賣出成本",
      estProfit: "估計淨利",
      roi: "ROI"
    },
    en: {
      eyebrow: "Tucson Zillow Value Lens",
      title: "Future Value Estimate",
      currentPrice: "Current price",
      foreign: "Foreign seller FIRPTA",
      years: "yr",
      advanced: "Mortgage and growth settings",
      down: "Down payment %",
      rate: "Mortgage rate %",
      app: "Appreciation adjustment %",
      range: "Range",
      annualGrowth: "Annual growth",
      remain: "Remaining loan",
      netProceeds: "Net sale proceeds",
      buyClosing: "Buy closing",
      annualCarry: "Annual carry",
      saleCosts: "Sale costs",
      estProfit: "Estimated profit",
      roi: "ROI"
    }
  };

  function t(key) {
    return I18N[lang][key];
  }

  const REGION_BASELINES = {
    tucson: { label: "圖森市整體", currentPrice: 325000, annualGrowth: 0.028, uncertainty: 0.10, hoa: 60, rentRatio: 0.0062 },
    "zip-85718": { label: "85718", currentPrice: 690000, annualGrowth: 0.032, uncertainty: 0.11, hoa: 140, rentRatio: 0.0053 },
    "zip-85750": { label: "85750", currentPrice: 620000, annualGrowth: 0.031, uncertainty: 0.11, hoa: 120, rentRatio: 0.0052 },
    "zip-85737": { label: "85737", currentPrice: 515000, annualGrowth: 0.026, uncertainty: 0.10, hoa: 110, rentRatio: 0.0055 },
    "zip-85704": { label: "85704", currentPrice: 365000, annualGrowth: 0.022, uncertainty: 0.10, hoa: 70, rentRatio: 0.0060 },
    "zip-85741": { label: "85741", currentPrice: 345000, annualGrowth: 0.024, uncertainty: 0.10, hoa: 75, rentRatio: 0.0061 },
    "zip-85742": { label: "85742", currentPrice: 372000, annualGrowth: 0.027, uncertainty: 0.10, hoa: 95, rentRatio: 0.0060 },
    "zip-85749": { label: "85749", currentPrice: 615000, annualGrowth: 0.030, uncertainty: 0.11, hoa: 90, rentRatio: 0.0051 },
    catalina: { label: "Catalina", currentPrice: 531609, annualGrowth: 0.024, uncertainty: 0.12, hoa: 70, rentRatio: 0.0052 },
    "central-tucson": { label: "Central Tucson", currentPrice: 315000, annualGrowth: 0.021, uncertainty: 0.10, hoa: 60, rentRatio: 0.0064 },
    "catalina-foothills": { label: "Catalina Foothills", currentPrice: 746960, annualGrowth: 0.030, uncertainty: 0.12, hoa: 140, rentRatio: 0.0050 }
  };

  const ZIP_TO_REGION = {
    "85718": "zip-85718",
    "85750": "zip-85750",
    "85737": "zip-85737",
    "85704": "zip-85704",
    "85741": "zip-85741",
    "85742": "zip-85742",
    "85749": "zip-85749",
    "85739": "catalina",
    "85716": "central-tucson"
  };

  function text(sel) {
    const el = document.querySelector(sel);
    return el ? el.textContent.trim() : "";
  }

  function parseNumber(input) {
    const match = String(input || "").replace(/,/g, "").match(/(\d+(\.\d+)?)/);
    return match ? Number(match[1]) : null;
  }

  function parseJsonLd() {
    const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
    for (const script of scripts) {
      try {
        const payload = JSON.parse(script.textContent);
        const entries = Array.isArray(payload) ? payload : [payload];
        for (const entry of entries) {
          if (entry && (entry["@type"] === "House" || entry["@type"] === "SingleFamilyResidence")) {
            return entry;
          }
        }
      } catch (_) {}
    }
    return null;
  }

  function extractListing() {
    const ld = parseJsonLd() || {};
    const title = ld.name || text("h1") || document.title;
    const address =
      (ld.address &&
        [ld.address.streetAddress, ld.address.addressLocality, ld.address.addressRegion, ld.address.postalCode]
          .filter(Boolean)
          .join(", ")) ||
      title;

    const price =
      parseNumber(ld.offers && ld.offers.price) ||
      parseNumber(text('[data-testid="price"]')) ||
      parseNumber(text("span[data-testid='price']")) ||
      parseNumber(document.body.innerText.match(/\$[\d,]+/));

    const beds =
      parseNumber(ld.numberOfRooms) ||
      parseNumber(text('[data-testid="bed-bath-beyond"]')) ||
      parseNumber(text("ul li")) ||
      3;

    const baths =
      parseNumber(ld.numberOfBathroomsTotal) ||
      parseNumber((document.body.innerText.match(/(\d+(\.\d+)?)\s*ba/i) || [])[1]) ||
      2;

    const sqft =
      parseNumber(ld.floorSize && ld.floorSize.value) ||
      parseNumber((document.body.innerText.match(/([\d,]+)\s*sqft/i) || [])[1]) ||
      1800;

    const zip = ((address.match(/\b(857\d{2}|856\d{2})\b/) || [])[1]) || ((location.pathname.match(/\b(857\d{2}|856\d{2})\b/) || [])[1]);
    const regionKey = ZIP_TO_REGION[zip] || "tucson";
    const region = REGION_BASELINES[regionKey] || REGION_BASELINES.tucson;
    return { title, address, price, beds, baths, sqft, zip, regionKey, region };
  }

  function estimate(listing, years, foreignSeller, inputs) {
    const baseline = listing.region;
    const areaAdj = 1 + ((listing.sqft - 1800) / 1800) * 0.12;
    const annualGrowth = Math.max(-0.05, baseline.annualGrowth + inputs.appreciationShift);
    const baseGrowth = Math.pow(1 + annualGrowth, years);
    const estimatedSale = listing.price * baseGrowth * areaAdj;
    const lowSale = estimatedSale * (1 - baseline.uncertainty);
    const highSale = estimatedSale * (1 + baseline.uncertainty);

    const downPaymentPct = inputs.downPaymentPct;
    const mortgageRate = inputs.mortgageRate;
    const propertyTaxPct = 0.014;
    const insurancePct = 0.0045;
    const maintenancePct = 0.01;
    const buyClosingPct = 0.02;
    const sellCostPct = 0.07;

    const downPayment = listing.price * downPaymentPct;
    const loanAmount = listing.price - downPayment;
    const monthlyRate = mortgageRate / 12;
    const termMonths = 360;
    const monthlyMortgage =
      (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, termMonths)) /
      (Math.pow(1 + monthlyRate, termMonths) - 1);
    const paymentsMade = years * 12;
    const remainingBalance = loanAmount > 0
      ? loanAmount * Math.pow(1 + monthlyRate, paymentsMade) -
        monthlyMortgage * ((Math.pow(1 + monthlyRate, paymentsMade) - 1) / monthlyRate)
      : 0;
    const annualCarry = listing.price * (propertyTaxPct + insurancePct + maintenancePct) + baseline.hoa * 12;
    const buyClosing = listing.price * buyClosingPct;
    const totalCashOut = downPayment + buyClosing + monthlyMortgage * 12 * years + annualCarry * years;

    const firpta = foreignSeller ? estimatedSale * 0.15 : 0;
    const saleCosts = estimatedSale * sellCostPct;
    const netProceeds = estimatedSale - saleCosts - firpta - remainingBalance;
    const profit = netProceeds - (downPayment + buyClosing + annualCarry * years);
    const profitPct = profit / Math.max(downPayment + buyClosing, 1);
    return {
      years,
      lowSale,
      estimatedSale,
      highSale,
      annualGrowth,
      monthlyMortgage,
      remainingBalance,
      annualCarry,
      buyClosing,
      saleCosts,
      netProceeds,
      firpta,
      profit,
      profitPct,
      totalCashOut
    };
  }

  function fmtMoney(v) {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(v);
  }

  function fmtPct(v) {
    return `${v >= 0 ? "+" : ""}${(v * 100).toFixed(1)}%`;
  }

  function renderPanel() {
    const listing = extractListing();
    if (!listing.price) return;

    const root = document.createElement("div");
    root.id = "tzvl-root";
    root.innerHTML = `
      <div class="tzvl-card">
        <div class="tzvl-header">
          <div>
            <div class="tzvl-eyebrow">${t("eyebrow")}</div>
            <h3>${t("title")}</h3>
          </div>
          <div class="tzvl-actions">
            <button class="tzvl-lang" type="button">${lang === "zh" ? "EN" : "中文"}</button>
            <button class="tzvl-close" type="button">×</button>
          </div>
        </div>
        <div class="tzvl-meta">${listing.address || listing.title}</div>
        <div class="tzvl-meta">${listing.region.label}${listing.zip ? ` · ${listing.zip}` : ""} · ${listing.beds || "?"} bed · ${listing.baths || "?"} bath · ${listing.sqft || "?"} sqft</div>
        <div class="tzvl-section">
          <div class="tzvl-price">${t("currentPrice")} ${fmtMoney(listing.price)}</div>
        </div>
        <div class="tzvl-toggle">
          <label><input id="tzvl-foreign" type="checkbox"> ${t("foreign")}</label>
        </div>
        <div class="tzvl-years" id="tzvl-years">
          <button type="button" data-years="2">2 ${t("years")}</button>
          <button type="button" data-years="3">3 ${t("years")}</button>
          <button type="button" data-years="4">4 ${t("years")}</button>
          <button type="button" data-years="5" class="active">5 ${t("years")}</button>
          <button type="button" data-years="10">10 ${t("years")}</button>
          <button type="button" data-years="20">20 ${t("years")}</button>
        </div>
        <details class="tzvl-advanced">
          <summary>${t("advanced")}</summary>
          <div class="tzvl-fields">
            <label>${t("down")}
              <input id="tzvl-down" type="number" min="0" max="100" step="1" value="25">
            </label>
            <label>${t("rate")}
              <input id="tzvl-rate" type="number" min="0" max="20" step="0.1" value="6.6">
            </label>
            <label>${t("app")}
              <input id="tzvl-app" type="number" min="-10" max="10" step="0.1" value="0">
            </label>
          </div>
        </details>
        <div id="tzvl-results"></div>
      </div>`;

    document.body.appendChild(root);
    root.querySelector(".tzvl-close").addEventListener("click", () => root.remove());
    root.querySelector(".tzvl-lang").addEventListener("click", () => {
      lang = lang === "zh" ? "en" : "zh";
      root.remove();
      renderPanel();
    });

    const resultsEl = root.querySelector("#tzvl-results");
    let selectedYears = 5;
    const renderResults = () => {
      const foreignSeller = root.querySelector("#tzvl-foreign").checked;
      const inputs = {
        downPaymentPct: (Number(root.querySelector("#tzvl-down").value) || 25) / 100,
        mortgageRate: (Number(root.querySelector("#tzvl-rate").value) || 6.6) / 100,
        appreciationShift: (Number(root.querySelector("#tzvl-app").value) || 0) / 100,
      };
      const row = estimate(listing, selectedYears, foreignSeller, inputs);
      resultsEl.innerHTML = `
        <div class="tzvl-row">
          <div class="tzvl-year">${row.years} ${t("years")}</div>
          <div class="tzvl-main">${fmtMoney(row.estimatedSale)}</div>
          <div class="tzvl-sub">${t("range")} ${fmtMoney(row.lowSale)} - ${fmtMoney(row.highSale)} · ${t("annualGrowth")} ${fmtPct(row.annualGrowth)}</div>
          <div class="tzvl-sub">${t("remain")} ${fmtMoney(row.remainingBalance)} · ${t("netProceeds")} ${fmtMoney(row.netProceeds)}</div>
          <div class="tzvl-sub">${t("buyClosing")} ${fmtMoney(row.buyClosing)} · ${t("annualCarry")} ${fmtMoney(row.annualCarry)} · ${t("saleCosts")} ${fmtMoney(row.saleCosts)}</div>
          <div class="tzvl-profit ${row.profit >= 0 ? "positive" : "negative"}">${t("estProfit")} ${fmtMoney(row.profit)} · ${t("roi")} ${fmtPct(row.profitPct)}</div>
        </div>`;
    };

    root.querySelector("#tzvl-foreign").addEventListener("change", renderResults);
    ["#tzvl-down", "#tzvl-rate", "#tzvl-app"].forEach((sel) => {
      root.querySelector(sel).addEventListener("input", renderResults);
    });
    root.querySelectorAll("#tzvl-years button").forEach((button) => {
      button.addEventListener("click", () => {
        selectedYears = Number(button.dataset.years);
        root.querySelectorAll("#tzvl-years button").forEach((b) => b.classList.remove("active"));
        button.classList.add("active");
        renderResults();
      });
    });
    renderResults();
  }

  setTimeout(renderPanel, 1200);
})();
